Product: Kirkby Box, September 2014

Designer: Simon Kirkby

Support:  http://forums.obrary.com/category/designs/kirkby-box

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary is a marketplace of products collaboratively designed by the community. These products can be produced by anyone, amateur or professional manufacturer, wherever economically or locally practical.

Description:
The Kirkby Box is made from plywood on a Laser Cutter.